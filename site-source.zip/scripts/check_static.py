"""Validate portable static paths, experiment links and exported mesh indices."""
import json
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
failures = []
checked_links = 0


def check_link(value, base=DIST):
    global checked_links
    if not value or value.startswith(('#', 'data:', 'mailto:', 'tel:')):
        return
    url = urlsplit(value)
    if url.scheme or url.netloc:
        return
    path = unquote(url.path)
    if not path:
        return
    if path.startswith('/'):
        failures.append('Root-relative asset breaks project Pages: ' + value)
        return
    target = (base / path).resolve()
    checked_links += 1
    if not target.is_relative_to(DIST.resolve()) or not target.is_file():
        failures.append('Missing or out-of-scope asset: ' + value)


class Links(HTMLParser):
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ('src', 'href'):
                check_link(value)


Links().feed((DIST / 'index.html').read_text())
for path in (DIST / 'assets').glob('*.css'):
    for value in re.findall(r'url\([\s\"\x27]*(.*?)[\s\"\x27]*\)', path.read_text()):
        check_link(value.strip('\"\x27 '), path.parent)


def walk(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, str) and (key.endswith('_url') or key == 'url'):
                check_link(item)
            walk(item)
    elif isinstance(value, list):
        for item in value:
            walk(item)


record = json.loads((DIST / 'assets/experiment-record.json').read_text())
walk(record)
meshes = list((DIST / 'assets/cases').rglob('mesh.json'))
for path in meshes:
    mesh = json.loads(path.read_text())
    vertices, faces = mesh['vertices'], mesh['faces']
    if not vertices or not faces:
        failures.append('Empty mesh: ' + str(path.relative_to(DIST)))
    if not all(len(v) == 3 for v in vertices):
        failures.append('Invalid vertex: ' + str(path.relative_to(DIST)))
    if not all(len(f) == 3 and all(isinstance(i, int) and 0 <= i < len(vertices) for i in f) for f in faces):
        failures.append('Invalid triangle: ' + str(path.relative_to(DIST)))

if failures:
    raise SystemExit('\n'.join(failures))
print(json.dumps({'status': 'passed', 'links_checked': checked_links, 'meshes_checked': len(meshes),
                  'recorded_cases': len(record['cases']),
                  'verified_B_cases': sum(c['routes']['B']['outcome'] == 'passed' for c in record['cases'])}, indent=2))
