# CAD Editing — Yanxi Lin

A portfolio of text-guided CAD editing with recorded Microsoft CAD-Editor model inference, interactive 3D comparisons, and downloadable experiment evidence.

The main gallery contains 9 verified end-to-end B-route edits. The optional diagnostic archive retains all 17 recorded cases and 51 calls across three batches. Route B uses the locating model's predicted mask; route A uses a target-assisted reference mask for diagnosis. These selected training examples are a demonstration, not a held-out accuracy benchmark.

## Features

- Synchronized original/output 3D views, with an optional reference target.
- English and Chinese interfaces.
- Original predicted masks, decoded model outputs, and STEP/STL downloads.
- Experiment records, attempt ledger, and a reproduction kit.
- A static website that requires no backend or browser-side model inference.

## GitHub Pages

The website files are in `dist/`. `.github/workflows/pages.yml` checks the static files and publishes that directory after a push to `main`.

For the first publication, set the repository's **Settings → Pages → Source** to **GitHub Actions**. Later pushes to `main` deploy automatically.

The configured project URL is `https://lyx-091610086.github.io/cad-editing-lab/`. Update the Open Graph URLs in `dist/index.html` if the owner or repository name changes.

## Validation

```bash
python3 scripts/check_static.py
node --check dist/assets/app.js
```

For local viewing, serve the `dist/` directory with any static HTTP server. Open the site over HTTP so the browser can load its JSON mesh files.

## Evidence and credits

`dist/assets/reproduction-kit.zip` contains the exported reproduction material. `experiment-record.json`, `attempt-ledger.csv`, and the per-case evidence files retain the inference and reconstruction records.

Research reproduction and engineering integration by Yanxi Lin. The model architecture and pretrained CAD-Editor checkpoints belong to the original authors. This project uses Meta Llama 3, CAD-Editor and third-party rendering tools; see `dist/assets/third-party-notices.txt` for the retained notices.

- [CAD-Editor paper](https://arxiv.org/abs/2502.03997)
- [Official CAD-Editor implementation](https://github.com/microsoft/CAD-Editor)
- [Original hosted portfolio](https://cad-editing-lab.free-harp-2721.chatgpt.site)
